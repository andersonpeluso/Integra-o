﻿

using System;
using System.Net.NetworkInformation;

namespace RMS.UTIL
{
    /// <summary>
    /// Comunicação com a balança Toledo.
    /// </summary>
    public class Toledo
    {
        /// <summary>
        /// Verifica se o IP está respondendo
        /// </summary>
        /// <exception cref="PingException">Não há comunicação.</exception>
        /// <param name="pEnderecoIP">Endereço IP</param>
        /// <returns>Boolean</returns>
        ///  <remarks>
        /// Criado por: Anderson Peluso.
        /// Criado em: 17/05/2017
        /// Alterado por:
        /// Alterado em: 
        /// </remarks>
        public static bool VerificaComunicacao(string pEnderecoIP)
        {
            bool lPingable = false;
            System.Net.NetworkInformation.Ping lPing = new System.Net.NetworkInformation.Ping();

            try
            {
                System.Net.NetworkInformation.PingReply lPingReply = lPing.Send(pEnderecoIP);
                lPingable = lPingReply.Status == System.Net.NetworkInformation.IPStatus.Success;
            }
            catch (PingException ex)
            {
                RMS.UTIL.Log.WriteSystemLog("Toledo", "VerificaComunicacao", "ERRO ***", ex.Message);
            }
            return lPingable;
        }

        /// <summary>
        /// Obtém o peso da balança.
        /// </summary>
        /// <exception cref="Exception">Falha ao obter o peso da balança.</exception>
        /// <param name="pEnderecoIP">Endereço IP da balança</param>
        /// <param name="pPortaComunicacao">Código da porta da balança</param>
        /// <returns></returns>
        /// <remarks>
        /// Criado por: Anderson Peluso.
        /// Criado em: 17/05/2017
        /// Alterado por:
        /// Alterado em: 
        /// </remarks>
        public static string GetPeso(string pEnderecoIP, System.Int32 pPortaComunicacao)
        {
            RMS.UTIL.Log.WriteSystemLog("Toledo", "GetPeso", "GetPeso", "INICIO: " + pEnderecoIP + "; " + pPortaComunicacao + ";");

            string lRetorno = string.Empty;

            try
            {
                if (!string.IsNullOrEmpty(pEnderecoIP) && pPortaComunicacao > 0)
                {
                    System.Net.IPAddress lIPAddress = System.Net.IPAddress.Parse(pEnderecoIP);
                    System.Net.Sockets.TcpClient lTcpClient = new System.Net.Sockets.TcpClient();

                    lTcpClient.Connect(lIPAddress, pPortaComunicacao);

                    System.Net.Sockets.NetworkStream lNetworkStream = lTcpClient.GetStream();

                    if (lNetworkStream.CanRead)
                    {
                        System.Byte[] lByte = new System.Byte[lTcpClient.ReceiveBufferSize];
                        lNetworkStream.Read(lByte, 0, lTcpClient.ReceiveBufferSize);

                        // PARA O FRAMEWORK SUPERIOR A 3.5
                        // lRetorno = System.Text.Encoding.Default.GetString(lByte);

                        System.Text.Encoding lASCII = System.Text.Encoding.ASCII;
                        System.Text.Encoding lUnicode = System.Text.Encoding.Unicode;

                        char[] lASCIIChars = new char[lASCII.GetCharCount(lByte, 0, lByte.Length)];
                        lASCII.GetChars(lByte, 0, lByte.Length, lASCIIChars, 0);

                        lRetorno = new string(lASCIIChars);
                    }

                    if (!string.IsNullOrEmpty(lRetorno))
                    {
                        lRetorno = lRetorno.Replace("\0", "");
                        lRetorno = lRetorno.Substring(7, 6);
                        lRetorno = lRetorno.TrimStart('0');

                        // Formatação
                        if (lRetorno.Length > 2)
                            lRetorno = lRetorno.Insert(lRetorno.Length - 2, ",");

                        if (lRetorno.Length > 6)
                            lRetorno = lRetorno.Insert(lRetorno.Length - 6, ".");
                    }
                }
                else
                    lRetorno = "0";
            }
            catch (Exception ex)
            {
                RMS.UTIL.Log.WriteSystemLog("Toledo", "GetPeso", "ERRO ***", ex.Message + ";");
            }
            RMS.UTIL.Log.WriteSystemLog("Toledo", "GetPeso", "GetPeso", "FIM: " + lRetorno + ";");
            return lRetorno;
        }
    }
}
