﻿
using System.IO;

namespace RMS.UTIL
{
    public class Log
    {
        /// <summary>
        /// Cria e escreve no log
        /// </summary>
        /// <exception cref="FileNotFoundException">Arquivo não encontrado.</exception>
        /// <param name="pClass">Nome da classe</param>
        /// <param name="pMethod">Nome do método</param>
        /// <param name="pRoutine">Descirção da rotina</param>
        /// <param name="pMessage">Descrição da mensagem</param>
        /// <returns>bool</returns>
        /// <remarks>
        /// Criado por: Anderson Peluso.
        /// Criado em: 17/05/2017
        /// Alterado por:
        /// Alterado em: 
        /// </remarks>
        public static bool WriteSystemLogRF(string pClass, string pMethod, string pRoutine, string pMessage)
        {
            bool lResult = false;

            try
            {
                // string lCurrentDirectory = System.IO.Directory.GetCurrentDirectory();

                if (!System.IO.Directory.Exists("\\Program Files" + "\\UTIL"))
                    System.IO.Directory.CreateDirectory("\\Program Files" + "\\UTIL");

                System.IO.StreamWriter lTexto = new System.IO.StreamWriter("\\Program Files" + "\\UTIL\\" + "log_" + System.DateTime.Now.ToString("ddMMyyyy") + ".log", true);

                System.Text.StringBuilder textoLog = new System.Text.StringBuilder();

                textoLog.Append("2.0.2" + "|");
                textoLog.Append(System.DateTime.Now.ToString("HH:mm:ss.fff") + " == ");
                textoLog.Append("Classe: " + pClass.PadRight(30));
                textoLog.Append("Método: " + pMethod.PadRight(40));
                textoLog.Append("Rotina: " + pRoutine.PadRight(50));
                textoLog.Append("Mensagem: " + pMessage);
                textoLog.Append("\r\n");

                lTexto.Write(textoLog);

                lTexto.Close();
                lResult = true;
            }
            catch (FileNotFoundException)
            {
            }
            return lResult;
        }

        /// <summary>
        /// Grava log.
        /// </summary>
        /// <exception cref="FileNotFoundException">Não há tratamento.</exception>
        /// <param name="pDiretorio">Diretório</param>
        /// <param name="pClasse">Nome da classe</param>
        /// <param name="pMetodo">Nome do método</param>
        /// <param name="pRotina">Rotina</param>
        /// <param name="pMensagem">Mensagem</param>
        /// <returns>Resukltado</returns>
        /// <remarks>
        /// Criado por: Anderson Peluso.
        /// Criado em: 10/12/2014
        /// Alterado por: Anderson Peluso
        /// Alterado em: 15/03/2017
        /// </remarks> 
        public static bool WriteSystemLog(string pClasse, string pMetodo, string pRotina, string pMensagem)
        {
            bool lResult = false;

            try
            {
                string lIp = "127.0.0.1";

                string lDiretorio = ChecksDirectory();

                // SEMPRE VAI EXISTIR
                if (!System.IO.Directory.Exists(lDiretorio))
                    System.IO.Directory.CreateDirectory(lDiretorio);

                System.IO.StreamWriter lTexto = new System.IO.StreamWriter(lDiretorio + "log_" + lIp + "_" + System.DateTime.Now.ToString("yyyyMMdd") + ".log", true);
                System.Text.StringBuilder textoLog = new System.Text.StringBuilder();

                textoLog.Append("2.0.2" + "|");
                textoLog.Append(System.DateTime.Now.ToString("HH:mm:ss:fff") + " == ");

                pClasse = char.ToUpper(pClasse[0]) + pClasse.Substring(1);
                pMetodo = char.ToUpper(pMetodo[0]) + pMetodo.Substring(1);
                pRotina = char.ToUpper(pRotina[0]) + pRotina.Substring(1);

                textoLog.Append("Classe: " + pClasse.PadRight(30));
                textoLog.Append("Método: " + pMetodo.PadRight(40));
                textoLog.Append("Rotina: " + pRotina.PadRight(50));

                pMensagem = pMensagem.Replace("\r", "");
                pMensagem = pMensagem.Replace("\n", "");

                //pMensagem = char.ToUpper(pMensagem[0]) + pMensagem.Substring(1);
                textoLog.Append("Mensagem: " + pMensagem);
                textoLog.Append("\r\n");
                lTexto.Write(textoLog);

                lTexto.Close();

                lResult = true;
            }
            catch (FileNotFoundException)
            {
            }
            return lResult;
        }

        /// <summary>
        /// Cria diretorio do log.
        /// </summary>
        /// <exception cref="DirectoryNotFoundException">Não há tratamento.</exception>
        /// <returns>Diretorio onde será armazenado o log.</returns>
        /// <remarks>
        /// Criado por: Anderson Peluso.
        /// Criado em: 17/05/2017
        /// Alterado por:
        /// Alterado em: 
        /// </remarks> 
        private static string ChecksDirectory()
        {
            string lPath = System.AppDomain.CurrentDomain.BaseDirectory.ToString();

            // UTILIZADO PARA GRAVAR NO DIRETORIO ACIMA.

            //string lPath2 = lPath.Remove(lPath.LastIndexOf("\\"));
            //lPath = lPath2.Remove(lPath2.LastIndexOf("\\") + 1);
            //lPath += "log";

            //if (!Directory.Exists(lPath))
            //    Directory.CreateDirectory(lPath);

            lPath += "RMS.UTIL.LOG\\";
            return lPath;
        }
    }
}
